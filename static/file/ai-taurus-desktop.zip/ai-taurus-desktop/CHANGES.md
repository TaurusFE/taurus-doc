## 当前版本

1. 重写了服务调用模块（原有模块暂时保留）,新模块只支持RESTful调用方式且去掉对`vue-resource`的依赖而直接使用`fetch`函数实现。

## 版本：0.1.11

1. 修正0.1.10版本不能使用的问题

2. 修正datatable组件若干问题

3. 修正组件初始化时无法通过js脚本获取国际化字符串的问题；

## 版本：0.1.10

此版本之前已经使用不能再次使用了，跳过。

## 版本：0.1.9

1. datatable增加了操作栏功能，增加了显示隐藏展开收起按钮的开关

2. 重构了Pager组件数据驱动逻辑；

3. status-message组件支持了多实例；

4. status-message组件支持了自动关闭；

5. status-message组件修改了api：

  * 将showMsg方法改为show方法；

  * 将closeMsg方法改为了hide方法；

  * 添加了close方法；

  * 去掉了fPosition和fType属性，去掉了position属性；

  * 将icon属性改名为icon-visibled属性；

  * 去掉了plugin属性；

6. loading的demo里添加了position的样式设置，解决了显示的问题。

7. 将taurus的依赖修改为 `node > 6.9.1`,`npm > 3.10.8`,请升级本地的node环境至最新的LTS版本

## 版本：0.1.5

1. 去掉了Tabs组件内部定义的样式；

2. 重构了Pager组件数据驱动逻辑；

3. 重构了服务调用模块，使其调用兼容restful和hub服务两种模式。

## 版本：0.1.3

1. 修正了NPM包内的assets目录内容不是最新的问题。

## 版本：0.1.2

1. 修正了TDataTable组件属性绑定问题。

## 版本：0.1.0

1. 针对Vue 2.0进行了全面升级。
