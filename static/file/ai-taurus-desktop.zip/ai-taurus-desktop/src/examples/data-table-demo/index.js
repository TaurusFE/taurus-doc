import {TDataTable, TSearchFilter} from 'taurus';

// 生成自定义内容模版片段，可以使用的模版变量是entry，它表示每一行对应的数据
new Vue({
  el: '#data-table-app',
  components: {
    TDataTable,
    TSearchFilter
  },
  data: {
    defaultTable: {
      columns: [
        {field: 'name', name: 'Name'},
        {field: 'age', name: 'Age'},
        {field: 'note', name: 'Note', componentId: 'note-component'}
      ],
      scrollColumns: [
        {field: 'name', name: 'Name', isFixed: true},
        {field: 'age', name: 'Age'},
        {field: 'age', name: 'Age'},
        {field: 'age', name: 'Age'},
        {field: 'age', name: 'Age'},
        {field: 'age', name: 'Age'},
        {field: 'age', name: 'Age'},
        {field: 'age', name: 'Age'},
        {field: 'age', name: 'Age'},
        {field: 'age', name: 'Age'},
        {field: 'age', name: 'Age'},
        {field: 'age', name: 'Age'},
        {field: 'age', name: 'Age'},
        {field: 'age', name: 'Age'},
        {field: 'age', name: 'Age'},
        {field: 'age', name: 'Age'},
        {field: 'age', name: 'Age'},
        {field: 'age', name: 'Age'},
        {field: 'age', name: 'Age'},
        {field: 'age', name: 'Age'},
        {field: 'age', name: 'Age'},
        {field: 'age', name: 'Age'},
        {field: 'age', name: 'Age'},
        {field: 'note', name: 'Note', componentId: 'note-component', isFixed: true}
      ],
      data: [
        {name: '<a>Aaron</a>', age: '17', note: 'This is a note', phoneNumber: '#18988027892', subTableTitle: 'Sub Table T1', account: '123412341', ean: '55555551', acc: 'Account-1', payer: 'Payer of Account-1', address: '324235345 Philadelfia'},
        {name: 'Marcus', age: '25', note: 'This is a note.', subTableTitle: 'Sub Table T2', account: '123412', ean: '55555552', acc: 'Account-2', payer: 'Payer of Account-2', address: '2000000 Philadelfia'},
        {name: 'Edison (Error!)', age: '38', error: true, subTableTitle: 'Sub Table T3', account: '1234123', ean: '55555553', acc: 'Account-3', payer: 'Payer of Account-3', address: '30000 Philadelfia'},
        {name: 'Hiram', age: '41', note: 'This is a note.', phoneNumber: '#18900000000', subTableTitle: 'Sub Table T4', account: '12', ean: '55555554', acc: 'Account-4', payer: 'Payer of Account-4', address: '400000 Philadelfia'},
        {name: 'Aaron', age: '16', expanded: true, subTableTitle: 'Sub Table T5', account: '1234', ean: '55555555', acc: 'Account-5', payer: 'Payer of Account-5', address: '500000 Philadelfia'},
        {name: 'Carter', age: '99', subTableTitle: 'Sub Table T6', account: '123412340', ean: '55555556', acc: 'Account-6', payer: 'Payer of Account-6', address: '600000 Philadelfia'}
      ],
      scrollData: [
        {name: '<a>Aaron</a>', age: '17', note: 'This is a note', phoneNumber: '#18988027892', subTableTitle: 'Sub Table T1', account: '123412341', ean: '55555551', acc: 'Account-1', payer: 'Payer of Account-1', address: '324235345 Philadelfia'},
        {name: 'Marcus', age: '25', note: 'This is a note.', subTableTitle: 'Sub Table T2', account: '123412', ean: '55555552', acc: 'Account-2', payer: 'Payer of Account-2', address: '2000000 Philadelfia'},
        {name: 'Edison (Error!)', age: '38', error: true, subTableTitle: 'Sub Table T3', account: '1234123', ean: '55555553', acc: 'Account-3', payer: 'Payer of Account-3', address: '30000 Philadelfia'},
        {name: 'Hiram', age: '41', note: 'This is a note.', phoneNumber: '#18900000000', subTableTitle: 'Sub Table T4', account: '12', ean: '55555554', acc: 'Account-4', payer: 'Payer of Account-4', address: '400000 Philadelfia'},
        {name: 'Aaron', age: '16', expanded: true, subTableTitle: 'Sub Table T5', account: '1234', ean: '55555555', acc: 'Account-5', payer: 'Payer of Account-5', address: '500000 Philadelfia'},
        {name: 'Carter', age: '99', subTableTitle: 'Sub Table T6', account: '123412340', ean: '55555556', acc: 'Account-6', payer: 'Payer of Account-6', address: '600000 Philadelfia'}
      ]
    },
    table1Setting: {
      mutiSelect: true,
      scrollMutiSelect: false,
      withPagination: true,
      dataCount: 6,
      pageSize: 3,
      localPage: true,
      fixedOperate: true,
      fixColumn: 'note',
      isShowExpandIcon: false
    }
  },
  created: function () {
    var vm = this;
    Vue.component('my-box-partial', {
      template: '#self-partial-template',
      props: ['rowData', 'index'],
      data: function () {
        return {
          dataList: vm.defaultTable.data
        };
      },
      methods: {
        toggle: function (rowId) {
          vm.defaultTable.data[rowId].expanded = false;
        }
      },
      watch: {
        'rowData.expanded': function (expanded) {
          if (expanded === true) {
            this.dataList = [
              {account: 1, ean: 'hello', acc: '000', payer: 'lalala', address: 'asia'},
              {account: 2, ean: 'hello', acc: '000', payer: 'lalala', address: 'asia'},
              {account: 3, ean: 'hello', acc: '000', payer: 'lalala', address: 'asia'},
              {account: 4, ean: 'hello', acc: '000', payer: 'lalala', address: 'asia'},
              {account: 5, ean: 'hello', acc: '000', payer: 'lalala', address: 'asia'}
            ];
          }
        }
      }
    });
    Vue.component('note-component', {
      template: '<div><button @click="onclick(rowData,index)">button</button><p>This is a note</p><span class="text-size--13"><a href="#">#18988027892</a></span></div>',
      props: ['rowData', 'index'],
      methods: {
        onclick: function (rowData, rowIndex) {
          alert('rowData:' + JSON.stringify(rowData) + 'rowindex:' + rowIndex);
        }
      }
    });
  },
  methods: {
    setData: function () {
      var data = [
        {name: '<a>AaronReload</a>', age: '17', note: 'This is a note', phoneNumber: '#18988027892', subTableTitle: 'Sub Table T1', account: '123412341', ean: '55555551', acc: 'Account-1', payer: 'Payer of Account-1', address: '324235345 Philadelfia'},
        {name: 'Marcus', age: '25', note: 'This is a note.', subTableTitle: 'Sub Table T2', account: '123412', ean: '55555552', acc: 'Account-2', payer: 'Payer of Account-2', address: '2000000 Philadelfia'},
        {name: 'Edison (Error!)', age: '38', error: true, subTableTitle: 'Sub Table T3', account: '1234123', ean: '55555553', acc: 'Account-3', payer: 'Payer of Account-3', address: '30000 Philadelfia'},
        {name: 'Hiram', age: '41', note: 'This is a note.', phoneNumber: '#18900000000', subTableTitle: 'Sub Table T4', account: '12', ean: '55555554', acc: 'Account-4', payer: 'Payer of Account-4', address: '400000 Philadelfia'},
        {name: 'Aaron', age: '16', expanded: true, subTableTitle: 'Sub Table T5', account: '1234', ean: '55555555', acc: 'Account-5', payer: 'Payer of Account-5', address: '500000 Philadelfia'},
        {name: 'Carter', age: '99', subTableTitle: 'Sub Table T6', account: '123412340', ean: '55555556', acc: 'Account-6', payer: 'Payer of Account-6', address: '600000 Philadelfia'}
      ];
      this.defaultTable.data = data;
      this.$refs.myDataTable.$refs.pager.pageNumberState = 1;
    },
    sortSecondColumn: function () {
      this.$refs.myDataTable.sortBy('age');
    },
    selectRow: function () {
      this.$refs.myDataTable.selectRow(1);
    },
    unselectRow: function () {
      this.$refs.myDataTable.unselectRow();
    },
    selectedRowId: function () {
      var selectedRowId = this.$refs.myDataTable.selectedRowId();
      if (selectedRowId === -1) {
        alert('没有选中任何行！');
      } else {
        alert('selectedRowId = ' + selectedRowId);
      }
    },
    toggleExpanded: function (rowId, expanded) {
      console.log('触发toggle自定义区事件');
    },
    rowSelected: function (rowId) {
      console.log('dt-select--rowId = ' + rowId);
    },
    rowUnselected: function (rowId) {
      console.log('dt-unselect--rowId = ' + rowId);
    },
    rowChecked: function (rowId) {
      console.log('dt-check--rowId = ' + rowId);
    },
    rowUnchecked: function (rowId) {
      console.log('dt-uncheck--rowId = ' + rowId);
    },
    allRowUnchecked: function () {
      console.log('dt-uncheck-all');
    },
    allRowChecked: function () {
      console.log('dt-check-all');
    },
    pageChanged: function (pageNumber, pageSize) {
      console.log('dt-page-changed--pageNumber = ' + pageNumber + ' ; pageSize = ' + pageSize);
    },
    getChecked: function () {
      var arr = this.$refs.myDataTable.getChecked();
      if (arr.length > 0) {
        alert('第一个勾选行对应的数据中的name属性值为：\n' + arr[0].name);
      } else {
        alert('没有勾选任何行！');
      }
    },
    getSelected: function () {
      var data = this.$refs.myDataTable.getSelected();
      if (data === null) {
        alert('你没有选中任何行！');
      } else {
        alert('当前选中行对应数据的name属性值为：' + data.name);
      }
    },
    // boxExpand: function (rowId, expanded) {
    //   if (expanded) {
    //     console.log('行' + rowId + '已经展开');
    //   } else {
    //     console.log('行' + rowId + '已经折叠');
    //   }
    // },
    removeRow: function () {
      var data = this.$refs.myDataTable.tableDataCache;
      if (data.length > 0) {
        data.pop();
      }
    },
    dtFixedTableEdit: function (data) {
      console.log('edit');
    },
    dtFixedTableDelete: function (data) {
      console.log('delete');
    },
    rowClick: function (data) {
      console.log('click');
    }
  }
});
