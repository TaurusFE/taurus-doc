import {TSelect, TRangeSlider} from 'taurus';

new Vue({
  el: '#range-slide',
  components: {
    TRangeSlider,
    TSelect
  },
  data: {
    rangeOptions: {
      isDrag: false,
      rangeLabel: 'Months',
      min: 0,
      max: 6,
      step: 1,
      start: 0,
      end: 3
    },
    singleSlideOptions: {
      rangeLabel: 'Months',
      type: 'single',
      min: 0,
      max: 6,
      step: 1,
      start: 0,
      end: 3
    },
    selectSlideOptions: {
      isDrag: true,
      type: 'select',
      rangeLabel: 'MB',
      min: 100,
      max: 600,
      start: 100,
      end: 300
    },
    options: [],
    defaultVal: ''

  },
  methods: {
    setRangeSlideStart: function (value) {
      this.rangeOptions.start = value;
    },
    setRangeSlideEnd: function (value) {
      this.rangeOptions.end = value;
    },
    setSingleRangeSlideEnd: function (value) {
      this.singleSlideOptions.end = value;
    }
  },
  mounted: function () { // 放一些初始化的动作
    this.$nextTick(function () {
      var _min = this.rangeOptions.min;
      var _max = this.rangeOptions.max;
      var _step = this.rangeOptions.step;
      for (var i = _min; i <= _max; i += _step) {
        var obj = {
          value: i,
          label: i + ' Month'
        };
        this.options.push(obj);
      }
      this.defaultVal = _min;
    });
  }
});
