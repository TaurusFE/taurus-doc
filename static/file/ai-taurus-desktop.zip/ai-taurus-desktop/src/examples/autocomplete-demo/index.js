import {TAutocomplete} from 'taurus';

new Vue({
  el: '#autocomplete-wrap',
  components: {
    TAutocomplete
  },
  data: {
    // delay: 1000,
    rearchResult: '',
    disabled: false,
    autoFocus: false,
    placeholder: 'sss',
    source: [
      'ActionScript',
      'AppleScript',
      'Asp',
      'BASIC',
      'C',
      'C++',
      'Clojure',
      'COBOL',
      'ColdFusion',
      'Erlang',
      'Fortran',
      'Groovy',
      'Haskell',
      'Java',
      'JavaScript',
      'Lisp',
      'Perl',
      'PHP',
      'Python',
      'Ruby',
      'Scala',
      'Scheme'
    ]
  },
  events: {
    'change': function (value) {
      console.log('change:' + value);
    },
    'close': function () {
      console.log('close dropdown menu');
    },
    'open': function () {
      console.log('open dropdown menu');
    }
  },
  methods: {
  }
});
