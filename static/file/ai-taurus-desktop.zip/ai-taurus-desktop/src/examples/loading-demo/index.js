import {TLoading} from 'taurus';

new Vue({
  el: '#loading-wrapper',
  components: {
    TLoading
  },
  data: {
    loader: 'loader',
    isShow: true,
    enabled: true,
    lightColor: false
  },
  methods: {
    showLoading: function () {
      this.$refs.myLoading.showLoading();
    },
    hideLoading: function () {
      this.$refs.myLoading.hideLoading();
    },
    onLoadingVisiable: function () {
      console.log('执行onLoadingVisiable回调');
    },
    onLoadingHidden: function () {
      console.log('执行onLoadingHidden回调');
    }
  }
});
new Vue({
  el: '#loading-wrapper_light',
  components: {
    TLoading
  },
  data: {
    loader: 'loader',
    isShow: true,
    enabled: true,
    lightColor: false
  },
  methods: {
    showLoading: function () {
      this.$refs.myLoading.showLoading();
    },
    hideLoading: function () {
      this.$refs.myLoading.hideLoading();
    },
    onLoadingVisiable: function () {
      console.log('执行onLoadingVisiable回调');
    },
    onLoadingHidden: function () {
      console.log('执行onLoadingHidden回调');
    }
  }
});
new Vue({
  el: '#loading-wrapper_circle',
  components: {
    TLoading
  },
  data: {
    enabled: true
  },
  methods: {
    showLoading: function () {
      this.$refs.myCircleLoading.showLoading();
    },
    hideLoading: function () {
      this.$refs.myCircleLoading.hideLoading();
    },
    onLoadingVisiable: function () {
      console.log('执行onLoadingVisiable回调');
    },
    onLoadingHidden: function () {
      console.log('执行onLoadingHidden回调');
    }
  }
});
new Vue({
  el: '#loading-wrapper_spinner',
  components: {
    TLoading
  },
  methods: {
    showLoading: function () {
      this.$refs.mySpinnerLoading.showLoading();
    },
    hideLoading: function () {
      this.$refs.mySpinnerLoading.hideLoading();
    },
    onLoadingVisiable: function () {
      console.log('执行onLoadingVisiable回调');
    },
    onLoadingHidden: function () {
      console.log('执行onLoadingHidden回调');
    }
  }
});
new Vue({
  el: '#loading-small_spinner',
  components: {
    TLoading
  },
  methods: {
    showLoading: function () {
      this.$refs.mySmallSpinner.showLoading();
    },
    hideLoading: function () {
      this.$refs.mySmallSpinner.hideLoading();
    },
    onLoadingVisiable: function () {
      console.log('执行onLoadingVisiable回调');
    },
    onLoadingHidden: function () {
      console.log('执行onLoadingHidden回调');
    }
  }
});
new Vue({
  el: '#fullScreen',
  components: {
    TLoading
  },
  data: {
    open: false
  },
  methods: {
    showLoading: function () {
      this.open = true;
      setTimeout(() => {
        this.hideLoading();
      }, 10000);
    },
    hideLoading: function () {
      this.open = false;
    },
    onLoadingVisiable: function () {
      console.log('执行onLoadingVisiable回调');
    },
    onLoadingHidden: function () {
      console.log('执行onLoadingHidden回调');
    }
  }
});
