import {TSearchFilter} from 'taurus';

new Vue({
  el: '#search-filter',
  components: {
    't-search-filter': TSearchFilter
  },
  data: {
    delay: 0,
    normalSearchResult: '',
    smallSearchResult: '',
    inlineSearchResult: '',
    smaillInlineSearchResult: ''
  },
  methods: {
    normalSearch: function (value) {
      console.log('normalSearchResult search:' + this.normalSearchResult);
    },
    smallSearch: function (value) {
      this.smallSearchResult = value;
    },
    inlineSearch: function (value) {
      this.inlineSearchResult = value;
    },
    smaillInlineSearch: function (value) {
      this.smaillInlineSearchResult = value;
    }
  }
});
