import {TDatePicker} from 'taurus';

new Vue({
  el: '#demo',
  data: {
    singleDateVal: '',
    doubleDateVal: '',
    singleDateTimeVal: '',
    doubleDateTimeVal: '',
    // dateVal: '2016.08.20 - 2016.09.21',
    dateFormat: 'yyyy-MMMM-dd hh:mm:ss'
  },
  components: {
    TDatePicker
  },
  methods: {
    setSingleDate: function () {
      this.singleDateVal = '2015-06-16';
    },
    setDoubleDate: function () {
      this.doubleDateVal = '2016.07.16 - 2016.08.10';
    },
    setDoubleDateTime: function () {
      this.doubleDateTimeVal = '2016.07.16 03:03:03 - 2016.08.10 04:04:04';
    },
    onChange: function (value) {
      alert(value);
    }
  },
  watch: {
    singleDateVal: function (newValue) {
      console.log('********Single Date Change********');
      console.log(newValue);
    },
    doubleDateVal: function (newValue) {
      console.log('********Double Date Change********');
      console.log(newValue);
    }
  }
});
