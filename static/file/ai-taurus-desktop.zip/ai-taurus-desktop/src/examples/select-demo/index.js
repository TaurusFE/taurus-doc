import {TSelect} from 'taurus';

var vm = new Vue({
  el: '#demo',
  components: {
    TSelect
  },
  data: function () {
    return {
      optionData: [{label: 'L1', value: 1}, {label: 'L2', value: 2}, {label: 'L3', value: 3}, {label: 'L4', value: 4}],
      optgroup: [
        {
          label: 'g1',
          value: [{label: 'gop1', value: 1}, {label: 'g2', value: 2}, {label: 'g3', value: 3}, {label: 'g4', value: 4}]
        },
        {
          label: 'g2',
          value: [
            {label: 'g21', value: 21}, {label: 'g22', value: 22}, {label: 'g23', value: 23}, {label: 'g24', value: 24}
          ]
        }
      ],
      disabled: false,
      selectVal: '2',
      selectTxt: '',
      selectOption: '',
      currentValue: ''
    };
  },
  methods: {
    btnClick: function () {
      alert(1);
    },
    dataChange: function (value, vm) {
      this.selectVal = value;
      this.selectTxt = vm.getText();
      this.selectOption = vm.getSelected();
    },
    clearSelect: function () {
      this.$refs.select1.clear();
    },
    resetSelect: function () {
      this.$refs.select1.reset();
    },
    toggleDisable: function () {
      this.disabled = !this.disabled;
    },
    setValue: function (value) {
      this.$refs.select1.setValue(value);
    },
    getValue: function () {
      alert(this.$refs.select1.getValue());
    },
    setModel: function () {
      this.currentValue = 1;
    }
  },
  watch: {
    currentValue (newValue) {
      console.log('*************');
      console.log(newValue);
    }
  }
});
console.log(vm);
