import {TButton} from 'taurus';

var vm = new Vue({
  el: '#demo',
  components: {
    TButton
  },
  methods: {
    btnClick: function () {
      alert('on click');
    },

    submit: function () {
      var promise = new Promise(function (resolve, reject) {
        window.setTimeout(function () {
          resolve();
        }, Math.random() * 2000 + 1000);
      });
      this.$refs.sbumitBtn.activityIndicator(promise);
    },
    finished: function () {
      alert('finished');
    },
    loaded: function () {
      alert('loaded');
      this.$refs.sbumitBtn.reset();
    }
  }
});
console.log(vm);
