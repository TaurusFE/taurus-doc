/**
 * Created by zengjie on 2016/10/18.
 */
export default {
  getEntitys: './common/fakeData.json'
};
