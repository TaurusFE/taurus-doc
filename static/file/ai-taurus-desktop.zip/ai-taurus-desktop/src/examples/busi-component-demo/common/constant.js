/**
 * Created by zengjie on 2016/10/13.
 */
export default {
  Status: {
    1: 'LinkOpened',
    2: 'ActiveBasket',
    3: 'Decline',
    4: 'Expired',
    5: 'Expired Soon',
    6: 'Purchase Ok',
    7: 'Verbal Accept'
  }
};
