import 'taurus';

new Vue({
  name: 'validator-demo',
  data () {
    return {
      sex: '--',
      results: {
        username: {
          valid: true
        },
        email: {
          valid: true
        }
      }
    };
  },
  validators: {
    email: {
      message: 'invalid email address', // error message with plain string
      check: function (val) { // define validator
        return /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(val);
      }
    }
  },
  computed: {
    requiredErrorMsg: function () {
      return 'Required fruit !!';
    }
  },
  methods: {
    submit: function (e) {
      // validate manually
      var self = this;
      this.$validate(true, function () {
        if (self.$demo.invalid) {
          e.preventDefault();
          return;
        }
        alert('submit succeed!');
      });
    },
    handleUserName: function (e) {
      this.handleValidate(e.target.$validity, 'username');
    },
    handleAddress: function (e) {
      this.handleValidate(e.target.$validity, 'email');
    },
    handleFruiteValidate: function (e) {
      this.handleValidate(e.target.$validity, 'fruits');
    },
    handleValidate: function ($validity, field) {
      var self = this;
      $validity.validate(function () {
        var result = $validity.result;
        console.log(result);
        self.results[field] = result;
      });
    }
  }
}).$mount('.container');
