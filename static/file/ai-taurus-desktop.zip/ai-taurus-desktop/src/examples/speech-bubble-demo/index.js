import {TSpeechBubble, TSpeechBubbleFilter, TSpeechBubbleFilterTree} from 'taurus';

new Vue({
  el: '#test',
  components: {
    TSpeechBubble
  },
  data: function () {
    return {
      exportSpeechBubble: {
        exportBtnId: 'showExportMoreBtn',
        size: 'large',
        title: '1112'
      }
    };
  },
  methods: {
    showExportMore () {
      this.$refs.exportSpeechBubble.open();
    }
  }
});

new Vue({
  el: '#speechBubbleDivLarge',
  components: {
    TSpeechBubble
  },
  data: function () {
    return {
      showSpeechBubbleBtnId: 'showSpeechBubbleBtnLarge',
      sizeSpeechBubble: 'large',
      titleSpeechBubble: '1112'
    };
  },
  methods: {
    openSpeechBubble: function () {
      if (!this.$refs.speechBubbleLarge.isShow) {
        this.$refs.speechBubbleLarge.open();
      } else {
        this.$refs.speechBubbleLarge.close();
      }
    },
    openEvent: function () {
      console.log('speech bubble is opend');
    },
    closeEvent: function () {
      console.log('speech bubble is closed');
    }
  }
});

new Vue({
  el: '#speechBubbleDivSmall',
  components: {
    TSpeechBubble
  },
  data: function () {
    return {
      showSpeechBubbleBtnId: 'showSpeechBubbleBtnSmall',
      sizeSpeechBubble: 'small',
      titleSpeechBubble: '1112'
    };
  },
  methods: {
    openSpeechBubble: function () {
      if (!this.$refs.speechBubbleSmall.isShow) {
        this.$refs.speechBubbleSmall.open();
      } else {
        this.$refs.speechBubbleSmall.close();
      }
    },
    openEvent: function () {
      console.log('speech bubble is opend');
    },
    closeEvent: function () {
      console.log('speech bubble is closed');
    }
  }
});

new Vue({
  el: '#speechBubbleFilterDivLarge',
  components: {
    TSpeechBubbleFilter
  },
  data: function () {
    return {
      showSpeechBubbleBtnId: 'showSpeechBubbleFilterBtnLarge',
      sizeSpeechBubble: 'large',
      titleSpeechBubble: 'Select columns',
      labels: 'item1,item2,item3,item4',
      checked: '0,1,0,0',
      disabled: '0,1,0,1',
      values: 'This,is,a,test',
      buttonName: 'Update table',
      checkedValue: ''
    };
  },
  methods: {
    openSpeechBubble: function () {
      if (!this.$refs.speechBubbleFilterLarge.isShow) {
        this.$refs.speechBubbleFilterLarge.open();
      } else {
        this.$refs.speechBubbleFilterLarge.close();
      }
    },
    openEvent: function () {
      console.log('speech bubble is opend');
    },
    closeEvent: function () {
      console.log('speech bubble is closed');
    },
    buttonClickEvent: function () {
      var items = this.$refs.speechBubbleFilterLarge.getCheckItem();
      console.log('speech bubble button click' + items);
    }
  }
});

new Vue({
  el: '#speechBubbleDivLargeTree',
  components: {
    TSpeechBubbleFilterTree
  },
  data: function () {
    return {
      showSpeechBubbleBtnId: 'showSpeechBubbleBtnLargeTree',
      sizeSpeechBubble: 'large',
      titleSpeechBubble: 'Select columns',
      buttonName: 'Update filter',
      checkedValue: '',
      items: [
        {
          label: 'item1',
          checked: false,
          value: 'value1',
          pid: '',
          id: 1
        },
        {
          label: 'item2',
          checked: false,
          value: 'value2',
          pid: 1,
          id: 2,
          count: 7
        },
        {
          label: 'item3',
          checked: false,
          value: 'value3',
          pid: 1,
          id: 3,
          count: 7
        },
        {
          label: 'item4',
          checked: true,
          value: 'value4',
          pid: '',
          id: 4,
          count: 0
        },
        {
          label: 'item5',
          checked: true,
          value: 'value5',
          pid: '',
          id: 5,
          count: 7
        },
        {
          label: 'item6',
          checked: true,
          value: 'value6',
          pid: 4,
          id: 6,
          count: 7
        },
        {
          label: 'item7',
          checked: true,
          value: 'value7',
          pid: 4,
          id: 7,
          count: 7
        }
      ]
    };
  },
  methods: {
    openSpeechBubble: function () {
      if (!this.$refs.largeSpeechBubbleTree.isShow) {
        this.$refs.largeSpeechBubbleTree.open();
      } else {
        this.$refs.largeSpeechBubbleTree.close();
      }
    },
    openEvent: function () {
      console.log('speech bubble is opend');
    },
    closeEvent: function () {
      console.log('speech bubble is closed');
    },
    buttonClickEvent: function () {
      var items = this.$refs.largeSpeechBubbleTree.getCheckItem();
      console.log('speech bubble button click' + items);
    }
  }
});
