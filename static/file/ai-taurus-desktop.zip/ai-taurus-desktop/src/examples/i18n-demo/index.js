import {taurus} from 'taurus';

const EMPTY_STRING = '';

new Vue({
  el: '#i18n-wrapper',
  data: function () {
    return {
      styleObject: {
        fontFamily: EMPTY_STRING
      }
    };
  },
  i18n: function (bizCode, newLang) {
    console.log('bizCode=' + bizCode + ' ; newLang=' + newLang);
    console.log('i18nDemo.form_evaluation_label=' + this.$t('i18nDemo.form_evaluation_label'));
  },
  methods: {
    changeLang: function () {
      taurus.lang = (taurus.lang === 'cn') ? 'en' : 'cn';
      if (taurus.lang === 'cn') {
        this.styleObject.fontFamily = '微软雅黑';
      } else {
        this.styleObject.fontFamily = EMPTY_STRING;
      }
    }
  }
});
