import {TNumberStepper} from 'taurus';

window.onload = function () {
  new Vue({
    name: 'num stepper',
    el: '.html',
    components: {
      't-number-stepper': TNumberStepper
    },
    data: {
      min: 0,
      max: 10,
      step: 2,
      normalStepperValue: 0
    },
    // computed: {
    //   max: function () {
    //     debugger;
    //     return isNaN(parseInt(this.max)) ? undefined : parseInt(this.max);
    //   }
    // },
    methods: {
      setNSValue: function (newValue) {
        this.$refs.nsNormal.setValue(newValue);
      },
      getNSValue: function () {
        let value = this.$refs.nsNormal.getValue();
        alert('类型' + typeof value + '; 值:' + value);
      },
      enable: function () {
        this.$refs.nsNormal.enable();
      },
      disable: function () {
        this.$refs.nsNormal.disable();
      },
      normalStepperChange: function (newValue, oldValue) {
        alert('newValue: ' + newValue + 'oldValue: ' + oldValue);
      }
    },
    watch: {
      normalStepperValue: function (newValue, oldValue) {
        console.log('newValue: ' + newValue + 'oldValue: ' + oldValue);
      }
    }
  });
};
