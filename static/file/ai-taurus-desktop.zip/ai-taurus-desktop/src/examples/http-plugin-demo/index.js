import {Interceptors} from 'taurus';

// 覆盖默认全局拦截器，在各类项目中，服务调用的返回报文结构可能存在差异
// 因此，可能需要定制返回报文的解析逻辑和错误处理逻辑，此过程通过拦截器完成

// 全局成功拦截器
Interceptors.succ = function (data, resolve, reject) {
  if (Object.keys(data).length === 0) {
    if (typeof reject === 'function') {
      reject('服务调用失败!');
    }
    return Promise.reject(new Error('服务调用失败!'));
  } else {
    if (typeof resolve === 'function') {
      resolve(data);
    }
    return Promise.resolve(data);
  }
};

// // 全局错误拦截器，除非特殊要求，一般不推荐自定义!
// Interceptors.error = function (error) {
//   var msg = error.message;
//   console.log('error.message = ' + msg);
//   return msg;
// };

new Vue({
  el: '#http-wrapper',
  data () {
    return {
      queryUrl: '/eshop/mvc/product/catalog',
      queryResult: '',
      createUrl: '/eshop/mvc/product/catalog',
      createBody: '{"aaa":"11"}',
      createResult: '',
      updateUrl: '/eshop/mvc/product/catalog',
      updateBody: '{"aaa":"11"}',
      updateResult: '',
      deleteUrl: '/eshop/mvc/product/catalog',
      deleteBody: '{"aaa":"11"}',
      deleteResult: '',
      url: '',
      body: ''
    };
  },
  methods: {
    queryCall () {
      var self = this;
      this.$httpx.query(this.queryUrl).then(function (json) {
        self.queryResult = JSON.stringify(json);
      }).catch(function (error) {
        console.log(error);
      });
    },
    createCall () {
      var self = this;
      this.$httpx.create(this.createUrl, {
        'data': this.createBody
      }).then(function (json) {
        self.createResult = JSON.stringify(json);
      }).catch(function (error) {
        console.log(error);
      });
    },
    updateCall () {
      var self = this;
      this.$httpx.delete(this.updateUrl, {
        'data': this.updateBody
      }).then(function (json) {
        self.updateResult = JSON.stringify(json);
      }).catch(function (error) {
        console.log(error);
      });
    },
    deleteCall () {
      var self = this;
      this.$httpx.delete(this.deleteUrl, {
        'data': this.deleteBody
      }).then(function (json) {
        self.deleteResult = JSON.stringify(json);
      }).catch(function (error) {
        console.log(error);
      });
    }
  }
});
