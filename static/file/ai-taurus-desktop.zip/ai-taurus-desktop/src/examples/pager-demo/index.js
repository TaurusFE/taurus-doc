import {TPager} from 'taurus';
new Vue({
  el: '#cntr',
  components: {
    TPager
  },
  data: {
    currentPageNumber: 1,
    currentPageSize: 5,
    currentDataCount: 90
  },
  methods: {
    changeDataCount: function () {
      this.currentDataCount += 10;
    },
    changePageSize: function () {
      this.currentPageSize = (this.currentPageSize === 5 ? 8 : 5);
    },
    pageChanged: function (pageNumber, pageSize) {
      this.currentPageNumber = pageNumber;
      console.log('page-changed事件被触发, 当前页号为: ' + pageNumber + '; 每页显示记录数为: ' + pageSize);
    },
    gotoPage7: function () {
      // this.$refs.myPager.activatePage(7); // 也可以使用这个方法
      this.currentPageNumber = 7;
    },
    prev: function () {
      // this.$refs.myPager.prev(); // 也可以使用这个方法
      if (this.currentPageNumber > 0) {
        this.currentPageNumber--;
      }
    },
    next: function () {
      // this.$refs.myPager.next(); // 也可以使用这个方法
      if (this.currentPageNumber < Math.ceil(this.currentDataCount / this.currentPageSize) + 1) {
        this.currentPageNumber++;
      }
    }
  }
});
