import urlTemplate from 'url-template';

var el = document.createElement('a');

const defaultOptions = {
  timeout: 30 * 1000,
  credentials: 'include'
};

var { slice } = [];
var actions = {
  get: {method: 'GET'},
  post: {method: 'POST'},
  create: {method: 'POST'},
  query: {method: 'GET'},
  update: {method: 'PUT'},
  delete: {method: 'DELETE'}
};

function isPlainObject (obj) {
  return (typeof (obj) === 'object' && obj !== null);
}
/**
 * 深复制
 * @param  {Object} target 目的对象
 * @param  {Object} source 源对象
 * @param  {Boolean} deep  是否深度复制
 */
function _merge (target, source, deep) {
  for (var key in source) {
    if (deep && (isPlainObject(source[key]) || Array.isArray(source[key]))) {
      if (isPlainObject(source[key]) && !isPlainObject(target[key])) {
        target[key] = {};
      }
      if (Array.isArray(source[key]) && !Array.isArray(target[key])) {
        target[key] = [];
      }
      _merge(target[key], source[key], deep);
    } else if (source[key] !== undefined) {
      target[key] = source[key];
    }
  }
}

// 深复制
function merge (target) {
  var args = slice.call(arguments, 1);
  args.forEach((source) => {
    _merge(target, source, true);
  });
  return target;
}

var Http = {};

for (let act in actions) {
  Http[act] = function (url, options) {
    var actionOption = actions[act];
    let newOptions = {};
    if (act !== 'get' && act !== 'post') {
      newOptions = {
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        }
      };
    };
    if (actions[act].method === 'POST') {
      newOptions.body = options.data;
    }
    merge(newOptions, actionOption, defaultOptions, options);
    if (/{/.test(url)) {
      url = urlTemplate.parse(url).expand(newOptions);
    }
    if (/^http:/.test(url) === false && /^https:/.test(url) === false) {
      el.href = url;
      url = el.href;
    }
    return new Promise(function (resolve, reject) {
      fetch(url, newOptions).then(function (res) {
        return res.json();
      }).then(function (json) {
        return Interceptors.succ(json, resolve, reject);
      }).catch(function (error) {
        return Interceptors.error(error);
      });
    });
  };
}

var PluginHttp = {
  _installed: false,
  install (Vue) {
    if (PluginHttp._installed) {
      return;
    }
    Vue.httpx = Http;
    Vue.prototype.$httpx = Http;
    PluginHttp._installed = true;
  }
};

// 默认拦截器，业务模块可以根据返回报文的特定结构进行逻辑定制。
var Interceptors = {
  succ (data, resolve, reject) {
    if (Object.keys(data).length === 0) {
      if (typeof reject === 'function') {
        reject('Service call failed!');
      }
      return Promise.reject('Service call failed!');
    } else {
      if (typeof resolve === 'function') {
        resolve(data);
      }
      return Promise.resolve(data);
    }
  },
  error (error) {
    return error;
  }
};

if (typeof window !== 'undefined' && window.Vue) {
  window.Vue.use(PluginHttp);
}
export {
  PluginHttp,
  Interceptors
};
