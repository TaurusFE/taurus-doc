/**
 * @module status-message
 * Taurus静态通知模块
 */
import Vue from 'vue';
import StatusMessage from '../components/status-message/status-message.vue';
import taurusConfig from '../utils/taurus-config';

const DEFAULTS = {
  type: 'info',
  iconVisibled: true,
  closable: true,
  content: ' '
};

var StatusMessageClass = Vue.extend(StatusMessage);
// 放在body下的时候需要的容器
var cntr = null;

function createContainer () {
  if (cntr === null) {
    cntr = document.createElement('div');
    // 默认消息提示位置为顶端
    cntr.setAttribute('class', 'message-wrapper ' + (taurusConfig.common.MESSAGE_POSITION === 'bottom' ? 'message--bottom' : 'message--top'));
    cntr.style.pointerEvents = 'none';
    document.body.appendChild(cntr);
  }
}

export default {
  _installed: false,
  install: function (Vue, options) {
    if (this._installed) {
      return;
    }
    createContainer();
    /**
     * 显示消息提示
     * @param  {Object}   options  选项
     * @param  {Function|String} callback 关闭回调
     * @example
     *  this.$message({
     *    el: 'massageId', //String, 容器id, message信息将append进容器末尾, Default 页面占位标签所在位置,没有占位标签则在页面顶部提示
     *    type: 'info', //String, Enumeration[info,success,alert,error], Default 'info'
     *    icon: true,   //Boolean, Default true
     *    close: true, //Boolean, Default true
     *    content: 'some info...' //String, Default null
     *  });
     */
    Vue.prototype.$message = function (options, callback) {
      var t = typeof options;
      var inst, box, delay;
      if (t === 'string') {
        options = Object.assign({content: options}, DEFAULTS);
      } else if (t !== 'object') {
        options = Object.assign({}, DEFAULTS);
      }
      if ('container' in options) {
        if (typeof options.container === 'string') {
          if (/^#/.test(options.container)) {
            box = document.getElementById(options.container.substr(1));
          } else if (/^./.test(options.container)) {
            box = document.querySelectorAll(options.container)[0];
          } else if (typeof options.container === 'object') {
            box = options.container;
          } else {
            box = cntr;
          }
        }
      } else {
        box = cntr;
      }
      inst = new StatusMessageClass({
        el: document.createElement('div')
      });
      box.appendChild(inst.$el);
      inst.$on('message-closed', callback);
      inst.type = options.type || DEFAULTS.type;
      inst.visibledState = true;
      inst.iconVisibled = options.iconVisibled || true;
      inst.oneOff = true;
      delay = options.delay;
      if (delay === 0) {
        inst.clearDelay();
      } else if (delay > 0) {
        inst.reDelay(delay);
      }
      inst.content = options.content || DEFAULTS.content;
    };
    Vue.message = Vue.prototype.$message;
    this._installed = true;
  }
};
