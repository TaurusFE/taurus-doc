/**
 * Created by zengjie on 2016/11/3.
 */
import cookieHelper from '../utils/cookie-helper';
import config from '../utils/taurus-config';
import constant from '../utils/constant';
var Plugin = {
  options: {
    headers: {
      acceptChannelType: cookieHelper.readCookie(constant.SEC_AUTH_CHANNELTYPE_KEY) || '',
      acceptProvCode: cookieHelper.readCookie(constant.SEC_AUTH_PROVCODE) || '',
      acceptChannelCode: cookieHelper.readCookie(constant.SEC_AUTH_CHANNELCODE_KEY) || '',
      notifyFlag: cookieHelper.readCookie(constant.SEC_AUTH_NOTIFYFLAG) || '',
      chargeFlag: cookieHelper.readCookie(constant.SEC_AUTH_CHARGEFLAG) || '',
      tenantId: cookieHelper.readCookie(constant.SEC_AUTH_TENANT_KEY) || '', // 租户，同veris租户
      locale: cookieHelper.readCookie(constant.I18N_LOCALE_KEY) || '', // 语言
      accessToken: cookieHelper.readCookie(constant.SEC_AUTH_TOKEN_KEY) || '', // 用户登录后分配的唯一序列
      roleType: cookieHelper.readCookie(constant.SEC_AUTH_ROLETYPE_KEY) || 'Visitor', // 角色类型
      appKey: cookieHelper.readCookie(constant.SEC_AUTH_APPKEY_KEY) || ''
    },
    timeout: 3 * 60 * 1000, // type:[number];Request timeout in milliseconds (0 means no timeout)
    // before: null, // type:[function(request)];Callback function to modify the request options before it is sent
    // progress: null, // type:[function(request)];Callback function to handle the ProgressEvent of uploads
    credentials: false, // type:[boolean];Indicates whether or not cross-site Access-Control requests should be made using credentials
    emulateHTTP: true, // type:[boolean];Send PUT, PATCH and DELETE requests with a HTTP POST and set the X-HTTP-Method-Override header
    emulateJSON: true // type:[boolean];Send request body as application/x-www-form-urlencoded content type
  },
  /**
   * 新增一个资源
   * @param options
   */
  create: function (options) {
    if (options && options.options) {
      setCustomOptions(options.options);
    }
    var promise = null;
    var isHub = isCallHub();
    if (isHub) {
      promise = this.hubPost(options);
    } else {
      var resource = Vue.resource(options.url);
      promise = resource.save(options.data);
    }
    return promise;
  },
  /**
   * 删除一个资源
   * @param options
   */
  delete: function (options) {
    var promise = null;
    var isHub = isCallHub();
    if (isHub) {
      promise = this.hubPost(options);
    } else {
      var resource = Vue.resource(options.url);
      promise = resource.delete(options.data);
    }
    return promise;
  },
  /**
   * 修改一个资源
   * @param options
   */
  update: function (options) {
    var promise = null;
    var isHub = isCallHub();
    if (isHub) {
      promise = this.hubPost(options);
    } else {
      var resource = Vue.resource(options.url);
      promise = resource.update(options.data);
    }
    return promise;
  },
  /**
   * 获取查询一个资源
   * @param options
   */
  query: function (options) {
    if (options && options.options) {
      setCustomOptions(options.options);
    }
    var promise = null;
    var isHub = isCallHub();
    if (isHub) {
      if (options && options.options && options.options.method.toUpperCase() === 'GET') {
        promise = this.hubGet(options);
      } else {
        promise = this.hubPost(options);
      }
    } else {
      // promise = Vue.http.get(options.url, options.data);
      var resource = Vue.resource(options.url);
      promise = resource.query(options.data);
    }
    return promise;
  },
  /**
   * set request headers
   * @param headers headers Map
   * @param isOverride 是否覆盖默认headers，为false则合并
   */
  setHeaders: function (headers, isOverride) {
    if (!headers || !isObject(headers)) {
      return;
    }
    if (isOverride === true) {
      for (let key in Plugin.options.headers) {
        if (Vue.http.headers.common.hasOwnProperty(key)) {
          delete Vue.http.headers.common[key];
        }
      }
      Plugin.options.headers = headers;
    } else {
      Object.assign(Plugin.options.headers, headers);
    }
    return Plugin.options.headers;
  },
  /**
   * 从服务器取出资源（一项或多项）
   * method: 'GET'
   * 可以结合URI Template一起使用,比如'http://211.149.193.19:8080/api/customers{/id}'
   * @param options
   */
  get: function (options) {
    if (options && options.options) {
      setCustomOptions(options.options);
    }
    return Vue.http.get(options.url);
  },
  /**
   * 返回新生成的资源对象
   * @param options
   */
  post: function (options) {
    if (options && options.options) {
      setCustomOptions(options.options);
    }
    return Vue.http.post(options.url, options.data, Plugin.options);
  },
  /**
   * hub方式post
   * @param options
   */
  hubGet: function (options) {
    return Vue.http.get(options.url, {
      headers: { // 这个写法是为了兼容7.x 中 参数不是标准的json
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Accept': 'application/json, text/javascript, */*; q=0.01'
      }
    }).then(function (response) {
      callbackHandler(response);
      return response;
    });
  },
  /**
   * hub方式post
   * @param options
   */
  hubPost: function (options) {
    if (options && options.data && typeof options.data === 'object') {
      options.data = JSON.stringify(options.data);
    } else {
      options.data = '';
    }
    var data = normalizeParameter(options.data);
    return Vue.http.post(options.url, data, {
      headers: { // 这个写法是为了兼容7.x 中 参数不是标准的json
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Accept': 'application/json, text/javascript, */*; q=0.01'
      }
    }).then(function (response) {
      callbackHandler(response);
      return response;
    });
  }
};
/**
 * 以hub还是restful方式call server
 * @returns {boolean}
 */
function isCallHub () {
  return config.common.SERVICE_SWICTH === constant.SERVICE_INVOCATION_TYPE.HUB;
}
/*
 * 将参数放入报文框架内
 * @param {string} p 参数字符串
 */
function normalizeParameter (p) {
  var s = p;
  var token = cookieHelper.readCookie(constant.SEC_AUTH_TOKEN_KEY) || '';
  var tenant = cookieHelper.readCookie(constant.SEC_AUTH_TENANT_KEY) || '';
  var roleType = cookieHelper.readCookie(constant.SEC_AUTH_ROLETYPE_KEY) || '';
  var zone = cookieHelper.readCookie(constant.SEC_AUTH_ZONE_KEY) || '';

  s += '&token=' + token + '&tenant=' + tenant + '&roleType=' + roleType + '&zone=' + zone;
  return 'WEB_HUB_PARAMS=' + s;
}
/**
 * set http options
 * headers:
 */
function setOptions (request) {
  for (let key in Plugin.options) {
    if (key === 'headers') {
      for (let header in Plugin.options.headers) {
        if (Plugin.options.headers[header]) {
          Vue.http.headers.common[header] = Plugin.options.headers[header] + '';
        }
      }
    } else {
      Vue.http.options[key] = Plugin.options[key];
    }
  }
  console.log('setOptions:');
  console.log(request);
}

/**
 * 设置自定义的option
 * @param options
 */
function setCustomOptions (options) {
  if (!options) {
    return;
  }
  for (let key in options) {
    if (Plugin.options.hasOwnProperty(key)) {
      if (isObject(Plugin.options[key])) {
        Plugin.options[key] = Object.assign(Plugin.options[key], options[key]);
      } else {
        Plugin.options[key] = options[key];
      }
    }
  }
  console.log('setCustomOptions');
  console.log(Plugin.options);
}

/**
 * 判断是否Object
 */
function isObject (o) {
  return Object.prototype.toString.call(o) === '[object Object]';
}
/**
 * 请求拦截处理器
 */
function serviceInterceptors (request, next) {
  // set options
  setOptions(request, Plugin.options);
  next(function (response) {
    if (!response.ok) {
      errorHandler(response);
    }
    return response;
  });
};

/**
 * 请求统一处理回调
 */
function callbackHandler (response) {
  if (typeof response.data === 'string') {
    response.data = JSON.parse(response.data);
  }
  if (response.data.hub_code !== '1' && response.data.hub_code !== 1) {
    var error = {
      errorMsg: 'callServer hub_code error',
      data: response.data
    };
    if (response.headers && response.headers['rspCode']) {
      error = {
        errorMsg: 'callServer rspCode error',
        rspCode: response.headers['rspCode'],
        rspDesc: response.headers['rspDesc']
      };
    }
    throw error;
  }
}

/**
 * 统一处理错误回调
 */
function errorHandler (response, errorMsg) {
  console.error(errorMsg || 'callServer error:');
  console.error(response.status);
  console.error(response.statusText);
}
var Service = {
  installed: false,
  install: function (vue) {
    if (Service.installed) {
      return;
    }
    vue.service = Plugin;
    vue.prototype.$service = Plugin;
    Service.installed = true;
    // 设置拦截器
    try {
      Vue.http.interceptors.push(serviceInterceptors);
    } catch (e) {
      throw e;
    }
  }
};

if (typeof window !== 'undefined' && window.Vue) {
  window.Vue.use(Service);
}
module.exports = Service;
