<template>
  <transition name="t-modal-scale">
    <div :class="'t-modal modal-box__content ' + classes"  v-show="value">
      <div :class="'t-modal-header ' + hdBackCss">
        <slot name="header-icon"></slot>
        <div class="t-modal-title text-light text-size--24 leader--xlarge" v-if="title">
            {{title}}
        </div>
        <i :class="'modal-box__close-btn icon ' + closeIcon" v-if="!hideIconClose" @click="close"></i>
      </div>
      <div class="t-modal-body">
        <slot>
          <div v-if="msg" v-html="msg"></div>
        </slot>
      </div>
      <div class="t-modal-footer" v-if="!hideClose">
        <slot name="footer"></slot>
      </div>
    </div>
  </transition>
</template>

<script>
import Popup from '../popup/popup';

const SIZE_LARGE = 'lg';
const SIZE_SMALL = 'sm';
const CSS_LARGE = 'modal-box--size-large';
const CSS_SMALL = 'modal-box--size-small';
const CSS_GRADIENT = 'gradient-line';
const CSS_PRELIGHT = 'pre-lightbox section--negative';
const CSS_ICON_REJECT = 'icon-reject';
const CSS_ICON_REJECT_PRE = 'icon-close-cross';
const CSS_FULL = 'modal-box__content--full';
const CSS_FULL_HD = 'padding-whole--large padding-toright--huge box--greyed rel border--bottom';
const CSS_ICON_BK = 'circle-background white with-border color-gray';
export default {
  mixins: [Popup],
  props: {
    title: {
      type: String,
      default: ''
    },
    msg: {
      type: String,
      default: ''
    },
    clickOverlayClose: {
      type: Boolean,
      default: true
    },
    hideClose: {
      type: Boolean,
      default: false
    },
    hideIconClose: {
      type: Boolean,
      default: true
    },
    special: {
      type: Boolean,
      default: false
    },
    size: {
      type: String,
      default: SIZE_SMALL
    },
    preLight: {
      type: Boolean,
      default: false
    },
    fullButton: {
      type: Boolean,
      default: false
    },
    fullHeader: {
      type: Boolean,
      default: false
    }
  },
  methods: {
    close () {
      this.$emit('input', false);
    },
    overlayClick () {
      if (this.clickOverlayClose) this.$emit('input', false);
    },
    escPress () {
      this.$emit('input', false);
    }
  },
  computed: {
    classes: function () {
      var classes = '';
      if (this.class) {
        classes += ' ' + this.class;
      }
      if (this.size === SIZE_LARGE) {
        classes += ' ' + CSS_LARGE;
      } else {
        classes += ' ' + CSS_SMALL;
      }
      if (!this.special) {
        classes += ' ' + CSS_GRADIENT;
      }
      if (this.preLight) {
        classes += ' ' + CSS_PRELIGHT;
      }
      if (this.fullButton) {
        classes += ' ' + CSS_FULL;
      }
      return classes;
    },
    closeIcon: function () {
      var classes = '';
      if (this.class) {
        classes += ' ' + this.class;
      }
      if (this.preLight || this.fullButton || this.fullHeader) {
        classes += ' ' + CSS_ICON_REJECT_PRE;
      } else {
        classes += ' ' + CSS_ICON_REJECT;
      }
      if (this.fullHeader) {
        classes += ' ' + CSS_ICON_BK;
      }
      return classes;
    },
    hdBackCss: function () {
      var classes = '';
      if (this.class) {
        classes += ' ' + this.class;
      }
      if (this.fullHeader) {
        classes += ' ' + CSS_FULL_HD;
      }
      return classes;
    }
  }
};
</script>
