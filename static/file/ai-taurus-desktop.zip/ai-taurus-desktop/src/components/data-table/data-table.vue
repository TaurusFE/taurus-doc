<template>
  <div style="position:relative;">
    <div>
      <!-- 固定列时使用 -->
      <table v-if="fixedColumnCache.length > 0" class="table table--adv table--fixed--left"
             :class="{'table--zebra': (zebra === true), 'table--without-hover': (expandable === true)}"
             :style="{width:fixedTableWidth+'px'}">
        <thead>
        <tr :style="{height:fixedHeadThHeight+'px'}" style="background: #fff">
          <th v-for="(col, index) in fixedColumnCache"
              class="invoices__table__column"
              :class="expandable !== true ? (sortOrders[col.field] === 1 ? 'sorting_asc' : (sortOrders[col.field] === -1 ? 'sorting_desc' : 'sorting')) : ''"
              @click="toggleSortBy(index)"
              :style="{width:fixedThWidth[index]+'px'}">
            {{col.name}}
          </th>
        </tr>
        </thead>
        <tbody>
        <template v-if="tableDataCache.length > 0">
          <template v-for="(entry, index) in tableDataCache
          | filterBy filterKey" track-by="index">
            <tr :class="{ 'row-selected': entry.selected, 'even': (index % 2 === 0), 'odd': (index % 2 !== 0), 'row--disable': entry.disabled, 'row--error': entry.error, 'expanded': (entry.expanded === true)}"
                :style="{height:fixedThHeight[index]+'px'}" v-on:click="selectRow(index, true)"  v-on:mouseover="_operateTrMouseover(index)" v-on:mouseout="_operateTrMouseout(index)"
                data-role="table-fixed-left-tr">
              <td v-for="col in fixedColumnCache">
                <template v-if="col.componentId">
                  <component :is="col.componentId" :row-data="entry" :index="index"></component>
                </template>
                <template v-else>
                  <div v-html="entry[col.field]">
                  </div>
                </template>
              </td>
            </tr>
            <tr v-if="expandable === true"
                class="drop-row"
                :class="entry.expanded === true ? '' : 'js-hidden'"
                :style="{height:fixedDropThHeight[index]+'px'}">
              <td class="text--center drop-item" :colspan="colspan">
              </td>
            </tr>
          </template>
        </template>
        </tbody>
      </table>

      <div class="table--scroll">
        <table class="table"
               :class="{'table--zebra': (zebra === true), 'table--without-hover': (expandable === true), 'table--fixed': (fixedColumnCache.length > 0), 'table--adv': (fixedColumnCache.length <= 0)}"
               style="display:table" data-role="data-table">
          <thead>
          <tr>
            <th v-if="expandable === true"
                class="text--center table__expand-cell"
                style="width:22px">
            </th>
            <template v-if="mutiSelect === true && tableDataCache.length > 0">
              <th class="form-checkbox invoices__table__column--checkbox all col--compact-5 form-checkbox--single sorting_disabled">
                <a class="form-checkbox--result" href="javascript:void(0);" :data-state="allCheckState" v-on:click.stop.prevent="toggleAllChecked">
                  <label></label>
                </a>
              </th>
              <th v-for="(col, index) in columnsCache"
                  class="invoices__table__column"
                  :class="expandable !== true ? (sortOrders[col.field] === 1 ? 'sorting_asc' : (sortOrders[col.field] === -1 ? 'sorting_desc' : 'sorting')) : ''"
                  @click="toggleSortBy(index)" :data-fixed="col.isFixed">
                {{col.name}}
              </th>
            </template>
            <template v-else>
              <th v-for="col in columnsCache"
                  class="invoices__table__column" :data-fixed="col.isFixed">
                {{col.name}}
              </th>
            </template>
          </tr>
          </thead>
          <tbody>
          <template v-if="tableDataCache.length > 0">
            <template v-for="(entry, index) in tableDataCache
          | filterBy filterKey"
                      track-by="index">
              <tr :class="{ 'row-selected': entry.selected, 'even': (index % 2 === 0), 'odd': (index % 2 !== 0), 'row--disable': entry.disabled, 'row--error': entry.error, 'expanded': (entry.expanded === true)}"
                  data-role="data-table-action-tr" v-on:click="selectRow(index, true)"  v-on:mouseover="_trMouseover(index)" v-on:mouseout="_trMouseout(index)">
                <td v-if="expandable === true" class="text--center table__expand-cell">
                  <div class="th_bill_trigger table__expander">
                    <a  v-if="isShowExpandIcon === true" class="icon-expand" href="javascript:void(0);" v-on:click="toggleBoxBy(index)"></a>
                  </div>
                </td>
                <td v-if="mutiSelect === true" class="form-checkbox form-checkbox--single invoices__table__column--checkbox">
                  <input type="checkbox" :checked="entry.checked" v-on:click.stop.prevent="toggleCheckedBy(index)"></input>
                  <label v-on:click.stop.prevent="toggleCheckedBy(index)"></label>
                </td>
                <td v-for="col in columnsCache">
                  <template v-if="col.componentId">
                    <component :is="col.componentId" :row-data="entry" :index="index"></component>
                  </template>
                  <template v-else>
                    <div v-html="entry[col.field]">
                    </div>
                  </template>
                </td>
              </tr>
              <tr v-if="expandable === true" class="drop-row" :class="entry.expanded === true ? '' : 'js-hidden'">
                <td class="text--center drop-item" :colspan="colspan">
                  <div class="drop-item-holder">
                    <component :is="detailRowComponent" :row-data="entry" :index="index"></component>
                  </div>
                </td>
              </tr>
            </template>
          </template>
          <tr v-if="tableDataCache.length === 0">
            <td class="dataTables_empty" :colspan="colspan">{{$t('no_matching')}}</td>
          </tr>
          </tbody>
        </table>
      </div>

      <!-- 悬浮操作列时使用 -->
      <table v-if="fixedOperate === true" data-role="fixed-data-table" class="table--default  table--adv table--action"
             :class="{'table--zebra': (zebra === true), 'table--without-hover': (expandable === true)}">
        <thead>
        <tr :style="{height:fixedHeadThHeight+'px'}">
          <template v-if="mutiSelect === true && tableDataCache.length > 0">
            <th>
            </th>
          </template>
          <template v-else>
            <th>
            </th>
          </template>
        </tr>
        </thead>
        <tbody>
        <template v-if="tableDataCache.length > 0">
          <template v-for="(entry, index) in tableDataCache
          | filterBy filterKey"
                    track-by="index">
            <tr :class="{ 'row-selected': entry.selected, 'even': (index % 2 === 0), 'odd': (index % 2 !== 0), 'row--disable': entry.disabled, 'row--error': entry.error, 'expanded': (entry.expanded === true)}"
                data-role="fixed-data-table-action-tr" :style="{height:fixedThHeight[index]+'px'}" v-on:mouseover="_operateTrMouseover(index)" v-on:mouseout="_operateTrMouseout(index)">
              <td>
                <div class="action-icon">
                  <span class="icon-pencil" @click="_fixedTabeleEdit(index)"></span>
                  <span class="icon-remove" @click="_fixedTableDelete(index)"></span>
                </div>
              </td>
            </tr>
            <tr v-if="expandable === true"
                class="drop-row"
                :class="entry.expanded === true ? '' : 'js-hidden'"
                :style="{height:fixedDropThHeight[index]+'px'}">
              <td class="text--center drop-item" :colspan="colspan">
              </td>
            </tr>
          </template>
        </template>
        </tbody>
      </table>
    </div>
    <div v-if="withPagination === true && tableDataCache.length > 0" class="form-row ovh">
      <div class="grid-row grid-row--gutter-none">
        <div class="col-md-6">
          <t-select :options="selectPageData" :default-value="selectPageDataDefault" size="small" v-on:on-change="_selectPageDataChange" style="width:100px;"></t-select>
        </div>
        <div class="col-md-6">
          <t-pager class="pull-right" :data-count="dataCount"
                   @page-changed="pageChanged"
                   :page-number="pageNumber"
                   :page-size="selectPageSize"
                   ref='pager'></t-pager>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import Vue from 'vue';
  import TPager from '../pager/pager.vue';
  import TSelect from '../select/select.vue';

  const STATE_ALL_SELECTED = 'all-selected';
  const STATE_SOME_SELECTED = 'some-selected';
  const STATE_UNSELECTED = '';
  export default {
    name: 'taurus-data-table',
    components: {
      TPager,
      TSelect
    },
    created: function () {
      this.selectPageSize = this.pageSizeComputed;
      this.columnsCache = this.columnsComputed;
      this._prevSelectedRowData = null;
      this._prevSortField = null;
      this._checkedCount = 0;
      // 此标志表示当allCheckState的值改变的时候是由什么操作引发的
      // 取值为：-1--由代码引发；0--由人机交互(通过数据绑定机制)触发
      this._changeSource = -1;

      // 如果是本地翻页，那么创建数据缓存
      if (this.localPage === true) {
        this.tableDataCache = this._getPageData(this.pageNumber, this.pageSize);
      } else {
        this.tableDataCache = this.tableData;
      }
      this._updateAllCheckState();

      // 对翻页的条数选择做初始化
      if (this.selectPageData.indexOf(this.pageSize) > -1) {
        this.selectPageDataDefault = this.pageSize;
      }
    },
    mounted: function () {
      this.$nextTick(function () {
        // 保证 this.$el 已经插入文档
        this.$watch('tableDataCache', function (newVal, oldVal) {
          var i, j;
          this._checkedCount = 0;
          if (newVal.length === 0) {
            this._prevSelectedRowData = null;
            this.allCheckState = STATE_UNSELECTED;
          }

          for (i = this.tableDataCache.length - 1; i >= 0; i--) {
            this.tableDataCache[i].selected = this.tableDataCache[i].selected || false;
            this.tableDataCache[i].error = this.tableDataCache[i].error || false;
            this.tableDataCache[i].disabled = this.tableDataCache[i].disabled || false;
            this.tableDataCache[i].expanded = this.tableDataCache[i].expanded || false;
            this.tableDataCache[i].checked = this.tableDataCache[i].checked || false;
            if (this.tableDataCache[i].checked) {
              this._checkedCount++;
            }
            // 如果没有传列对应的值,给它赋值个空字符串
            for (j = this.columnsCache.length - 1; j >= 0; j--) {
              if (!this.tableDataCache[i][this.columnsCache[j].field]) {
                this.tableDataCache[i][this.columnsCache[j].field] = '';
              }
            }
          }
          this._setFixedColumn();
        });
        this.$watch('tableData', function (newVal, oldVal) {
          if (this.localPage === true) {
            this.tableDataCache = this._getPageData(this.pageNumber, this.pageSize);
          } else {
            this.tableDataCache = newVal;
          }
        });
        this.$watch('allCheckState', function (newVal) {
          if (this._changeSource === 0) {
            this._changeSource = -1;
            if (newVal === STATE_UNSELECTED) {
              this.uncheckAll(true);
            } else {
              this.checkAll(true);
            }
          }
        });
      });
      // 固定列位置校正
      if (this.fixedOperate || this.fixedColumnCache.length > 0) {
        this._setFixedColumn();
      }
    },
    props: {
      detailRowComponent: String,
      // 实际数据总数，在localPage为false的时候必须设置这个属性!
      dataCount: {
        type: Number,
        default: 0,
        validator: function (value) {
          return /^\d+$/.test(value);
        }
      },
      pageNumber: {
        default: 1,
        type: Number,
        validator: function (value) {
          return /^\d+$/.test(value);
        }
      },
      withPagination: {
        type: Boolean,
        default: false
      },
      localPage: {
        type: Boolean,
        default: false
      },
      pageSize: {
        default: 5,
        type: Number,
        validator: function (value) {
          return /^\d+$/.test(value);
        }
      },
      tableData: {
        type: Array,
        default: function () {
          return [];
        }
      },
      columns: {
        type: Array,
        default: function () {
          return [];
        }
      },
      zebra: {
        type: Boolean,
        default: false
      },
      filterKey: String,
      expandable: {
        type: Boolean,
        default: false
      },
      mutiSelect: {
        type: Boolean,
        default: true
      },
      /*
       * 是否有行选中的效果和事件 默认关闭
       */
      isSelectable: {
        type: Boolean,
        default: false
      },
      /*
       * 是否有操作按钮
       */
      fixedOperate: {
        type: Boolean,
        default: false
      },
      /* fixedColumn: {
        type: String,
        default: 'note,name'
      }, */
      isShowExpandIcon: {
        type: Boolean,
        default: true
      }
    },
    data: function () {
      var sortOrders = {};
      this.columns.forEach(function (col) {
        sortOrders[col.field] = 0;
      });
      return {
        allCheckState: '', // 默认所有复选框都不勾选
        sortKey: '',
        sortOrders: sortOrders,
        onText: 'Yes',
        offText: 'No',
        selectPageData: [5, 10, 15],
        selectPageDataDefault: '',
        selectPageSize: 0,
        tableDataCache: [],
        fixedColumnCache: [],
        fixedHeadThHeight: 0,
        fixedThWidth: [],
        fixedThHeight: [],
        fixedFirstLeft: 0,
        fixedTableWidth: 0,
        fixedDropThHeight: [],
        columnsCache: []
      };
    },
    computed: {
      colspan: function () {
        var count = this.columnsCache.length;
        if (this.mutiSelect) {
          count++;
        }
        if (this.expandable) {
          count++;
        }
        return count;
      },
      pageSizeComputed: function () {
        this.selectPageSize = this.pageSize;
        return this.selectPageSize;
      },
      columnsComputed: function () {
        // colums重新排序 固定列排在前面
        var fixedArr = [];
        var normalArr = [];
        this.columns.forEach(function (col) {
          if (col.isFixed) {
            fixedArr.push(col);
          } else {
            normalArr.push(col);
          }
        });
        this.fixedColumnCache = fixedArr;
        this.columnsCache = fixedArr.concat(normalArr);
        return this.columnsCache;
      }
    },
    methods: {
      _getStart: function (pageNumber, pageSize) {
        var pn = pageNumber || this.$refs.pager.pageNumber;
        return (pn - 1) * pageSize + 1;
      },
      _getEnd: function (pageNumber, pageSize) {
        pageNumber = pageNumber || this.$refs.pager.pageNumber;
        return pageNumber * pageSize;
      },
      _getPageData: function (pageNumber, pageSize) {
        var cache = this.tableData;
        var start = this._getStart(pageNumber, pageSize) - 1;
        var end = this._getEnd(pageNumber, pageSize);
        var arr = [];
        var i;
        if (end > cache.length) {
          end = cache.length;
        }
        for (i = start; i < end; i++) {
          arr.push(cache[i]);
        }
        return arr;
      },
      _updateAllCheckState: function () {
        if (this._checkedCount === 0) {
          this.allCheckState = STATE_UNSELECTED;
        } else if (this._checkedCount === this.tableDataCache.length) {
          this.allCheckState = STATE_ALL_SELECTED;
        } else {
          this.allCheckState = STATE_SOME_SELECTED;
        }
      },
      _dataExist: function (rowId) {
        return (rowId >= 0 && rowId <= this.tableDataCache.length - 1);
      },
      pageChanged: function (pageNumber, pageSize) {
        if (this.localPage === true) {
          this.tableDataCache = this._getPageData(pageNumber, pageSize);
        } else {
          this.$emit('dt-page-changed', pageNumber, pageSize);
        }
      },
      /**
       * 切换储物箱的展开或收起状态
       * @param  {Number} rowId 行Id
       * @return {[type]}       [description]
       */
      toggleBoxBy: function (rowId) {
        var expanded;
        if (this._dataExist(rowId)) {
          expanded = !this.tableDataCache[rowId].expanded;
          this._changeDataBy(rowId, 'expanded', expanded);
          this.$emit('dt-toggle-expanded', rowId, expanded);
        }
      },
      /**
       * 按指定列排序，该方法将会在升序和降序之间来回切换
       * @param {Number} columnIndex 列序号
       */
      toggleSortBy: function (columnIndex) {
        var col, sortOrder;
        if (this.expandable) {
          return;
        }
        col = this.columnsCache[columnIndex];
        sortOrder = this.sortOrders[col.field];
        if (sortOrder !== 0) {
          sortOrder = sortOrder * -1;
        } else {
          sortOrder = 1;
        }
        if (this._prevSortField !== null && this._prevSortField !== col.field) {
          this.sortOrders[this._prevSortField] = 0; // 去掉列头排序图标
        }
        this.sortOrders[col.field] = sortOrder;
        this._prevSortField = col.field;
        this.sortKey = col.field;
        this.sortBy(col.field, sortOrder);
      },
      /**
       * 按指定列排序，该方法将会在升序和降序之间来回切换
       * @param {String} sortKey 列code
       * @param {Number} sortOrder 排序顺序，1为升序；-1为降序
       */
      sortBy: function (sortKey, sortOrder) {
        var asc, desc, sorter;
        asc = function (a, b) {
          if (a[sortKey] < b[sortKey]) {
            return -1;
          } else if (a[sortKey] > b[sortKey]) {
            return 1;
          } else {
            return 0;
          }
        };
        desc = function (a, b) {
          if (a[sortKey] < b[sortKey]) {
            return 1;
          } else if (a[sortKey] > b[sortKey]) {
            return -1;
          } else {
            return 0;
          }
        };
        sorter = (sortOrder === 1 ? asc : desc);
        this.tableDataCache.sort(sorter);
      },
      /**
       * 切换勾选所有复选框勾选状态
       */
      toggleAllChecked: function () {
        if (this.mutiSelect) {
          if (this.allCheckState === STATE_UNSELECTED) {
            this.allCheckState = STATE_ALL_SELECTED;
          } else {
            this.allCheckState = STATE_UNSELECTED;
          }
          this._changeSource = 0;
          if (this.allCheckState === STATE_UNSELECTED) {
            this.uncheckAll(true);
          } else {
            this.checkAll(true);
          }
        }
      },
      toggleCheckedBy: function (rowId) {
        if (this.mutiSelect && this._dataExist(rowId)) {
          if (this.tableDataCache[rowId].checked) {
            this.uncheckRow(rowId, true);
          } else {
            this.checkRow(rowId, true);
          }
        }
      },
      /**
       * 设置所有显示行勾选状态
       * @param {Boolean} checked 是否勾选，true为勾选；false为不勾选
       */
      _setCheckAll: function (checked) {
        var i;
        if (this.mutiSelect) {
          for (i = this.tableDataCache.length - 1; i >= 0; i--) {
            if (this.tableDataCache[i].disabled) {
              continue;
            }
            this._changeDataBy(i, 'checked', checked);
          }
        }
      },
      /**
       * 勾选所有显示行
       * @param {Boolean|undefined} [fireEvent] 是否触发事件，为true表示触发事件，否则不触发
       */
      checkAll: function (fireEvent) {
        if (this._checkedCount === this.tableDataCache.length) {
          return;
        }
        this._setCheckAll(true);
        this._checkedCount = this.tableDataCache.length;
        this._updateAllCheckState();
        if (fireEvent) {
          this.$emit('dt-check-all');
          this.$emit('dt-check-state-changed');
        }
      },
      /**
       * 取消勾选所有显示行
       * @param {Boolean|undefined} [fireEvent] 是否触发事件，为true表示触发事件，否则不触发
       */
      uncheckAll: function (fireEvent) {
        if (this._checkedCount === 0) {
          return;
        }
        this._setCheckAll(false);
        this._checkedCount = 0;
        this._updateAllCheckState();
        if (fireEvent) {
          this.$emit('dt-uncheck-all');
          this.$emit('dt-check-state-changed');
        }
      },
      /**
       * 勾选行
       * @param {Number} rowId 行Id
       * @param {Boolean|undefined} [fireEvent] 是否触发事件，为true表示触发事件，否则不触发
       */
      checkRow: function (rowId, fireEvent) {
        if (this.mutiSelect && this._dataExist(rowId)) {
          if (this.tableDataCache[rowId].disabled) {
            return;
          }
          this._changeDataBy(rowId, 'checked', true);
          this._checkedCount++;
          this._updateAllCheckState();
          if (fireEvent) {
            this.$emit('dt-check', rowId);
            this.$emit('dt-check-state-changed');
          }
        }
      },
      /**
       * 取消勾选行
       * @param {Number} rowId 行Id
       * @param {Boolean|undefined} [fireEvent] 是否触发事件，为true表示触发事件，否则不触发
       */
      uncheckRow: function (rowId, fireEvent) {
        if (this.mutiSelect && this._dataExist(rowId)) {
          if (this.tableDataCache[rowId].disabled) {
            return;
          }
          this._changeDataBy(rowId, 'checked', false);
          this._checkedCount--;
          this._updateAllCheckState();
          if (fireEvent) {
            this.$emit('dt-uncheck', rowId);
            this.$emit('dt-check-state-changed');
          }
        }
      },
      _changeDataBy: function (rowId, prop, value) {
        var item = Object.assign({}, this.tableDataCache[rowId]);
        if (this.tableDataCache[rowId][prop] !== value) {
          item[prop] = value;
          Vue.set(this.tableDataCache, rowId, item);
        }
      },
      _getActualRowId: function (rowId) {
        var el = this.$el.querySelectorAll('[data-org-index="' + rowId + '"]');
        return (el.length > 0) ? (el[0].rowIndex - 1) : null;
      },
      /**
       * 选择行
       * @param {Number} rowId 行Id
       * @param {Boolean|undefined} [fireEvent] 是否触发事件，为true表示触发事件，否则不触发
       */
      selectRow: function (rowId, fireEvent) {
        var prevRowId;
        // 是否打开选中开关&&是否不是可展开状态
        if (this.isSelectable && this.expandable === false && this._dataExist(rowId)) {
          if (this.tableDataCache[rowId].disabled) {
            return;
          }
          if (this._prevSelectedRowData !== null) {
            prevRowId = this.tableDataCache.indexOf(this._prevSelectedRowData);
            if (prevRowId !== rowId) {
              this.unselectRow(fireEvent);
            } else {
              return;
            }
          }
          this._changeDataBy(rowId, 'selected', true);
          this._prevSelectedRowData = this.tableDataCache[rowId];
          if (fireEvent) {
            this.$emit('dt-select', rowId);
          }
        } else {
          // 点击事件
          this.$emit('dt-row-click', rowId);
        }
      },
      /**
       * 取消选中行
       * @param {Boolean|undefined} [fireEvent] 是否触发事件，为true表示触发事件，否则不触发
       */
      unselectRow: function (fireEvent) {
        var idx;
        if (this.isSelectable && this.expandable === false) {
          idx = this.selectedRowId();
          if (idx > -1 && this.tableDataCache[idx].disabled === false) {
            this._changeDataBy(idx, 'selected', false);
            if (fireEvent) {
              this.$emit('dt-unselect', idx);
            }
            this._prevSelectedRowData = null;
          }
        }
      },
      selectedRowId: function () {
        return this.tableDataCache.indexOf(this._prevSelectedRowData);
      },
      getSelectedCount: function () {
        return (this._prevSelectedRowData === null ? 0 : 1);
      },
      getSelected: function () {
        var idx = this.selectedRowId();
        if (idx > -1) {
          return this.tableDataCache[idx];
        }
        return null;
      },
      getCheckedCount: function () {
        var count = 0;
        if (this.mutiSelect) {
          this.tableDataCache.forEach(function (item) {
            if (item.checked) {
              count++;
            }
          });
          return count;
        }
        return 0;
      },
      getChecked: function () {
        var arr = [];
        this.tableDataCache.forEach(function (item) {
          if (item.checked) {
            arr.push(item);
          }
        });
        return arr;
      },
      checkedRowIds: function () {
        var arr = [];
        this.tableDataCache.forEach(function (item, idx) {
          if (item.checked) {
            arr.push(idx);
          }
        });
        return arr;
      },
      _selectPageDataChange: function (value, vm) {
        if (value !== '' && !isNaN(value)) {
          this.selectPageSize = value;
        }
      },
      _setFixedColumn: function () {
        // 动态copy一个新的table做固定列
        if (this.$el) {
          var table = this.$el.querySelector('[data-role="data-table"]');
          var thead = table.querySelector('thead');
          var tbody = table.querySelector('tbody');
          var headTr = thead.querySelector('tr');
          var headTh = headTr.querySelectorAll('th');
          var i, j, height;
          this.fixedThHeight = [];
          this.fixedDropThHeight = [];
          this.fixedFirstLeft = 0;
          this.fixedTableWidth = 0;
          // 只需要tbody下的子节点
          var trs = tbody.children;
          if (headTr) {
            this.fixedHeadThHeight = headTr.clientHeight;
            for (j = 0; j < headTh.length; j++) {
              if (headTh[j].className.indexOf('invoices__table__column') > -1 && (headTh[j].getAttribute('data-fixed') === 'true')) {
                this.fixedThWidth.push(headTh[j].clientWidth);
                this.fixedTableWidth += headTh[j].clientWidth;
                if (!this.fixedFirstLeft || this.fixedFirstLeft === 0) {
                  this.fixedFirstLeft = headTh[j].offsetLeft;
                }
              }
            }
          }
          for (i = 0; i < trs.length; i++) {
            height = trs[i].clientHeight;
            if (trs[i].className.indexOf('drop-row') === -1) {
              this.fixedThHeight.push(height);
            } else {
              this.fixedDropThHeight.push(height);
            }
          }
        }
      },
      _fixedTabeleEdit: function (index) {
        if (this.tableDataCache[index]) {
          this.$emit('dt-fixed-table-edit', this.tableDataCache[index]);
        }
      },
      _fixedTableDelete: function (index) {
        if (this.tableDataCache[index]) {
          this.$emit('dt-fixed-table-delete', this.tableDataCache[index]);
        }
      },
      _trMouseover: function (index) {
        var trs = this.$el.querySelectorAll('[data-role="fixed-data-table-action-tr"]');
        if (this.fixedOperate && trs[index].className.indexOf('table--action-hover') <= -1) {
          trs[index].className += ' ' + 'table--action-hover';
        }
        var fixedLeftTrs = this.$el.querySelectorAll('[data-role="table-fixed-left-tr"]');
        if (this.fixedColumnCache.length > 0 && fixedLeftTrs[index].className.indexOf('.table--fixed--left-hover') <= -1) {
          fixedLeftTrs[index].className += ' ' + 'table--fixed--left-hover';
        }
      },
      _trMouseout: function (index) {
        var trs = this.$el.querySelectorAll('[data-role="fixed-data-table-action-tr"]');
        if (this.fixedOperate && trs[index].className.indexOf('table--action-hover') > -1) {
          trs[index].className = trs[index].className.replace(new RegExp('(\\s|^)' + 'table--action-hover' + '(\\s|$)'), '');
        }
        var fixedLeftTrs = this.$el.querySelectorAll('[data-role="table-fixed-left-tr"]');
        if (this.fixedColumnCache.length > 0 && fixedLeftTrs[index].className.indexOf('.table--fixed--left-hover') <= -1) {
          fixedLeftTrs[index].className = fixedLeftTrs[index].className.replace(new RegExp('(\\s|^)' + 'table--fixed--left-hover' + '(\\s|$)'), '');
        }
      },
      _operateTrMouseover: function (index) {
        if (!this.expandable || this.fixedColumnCache.length > 0) {
          var trs = this.$el.querySelectorAll('[data-role="data-table-action-tr"]');
          if (this.fixedOperate && trs[index].className.indexOf('box--grey') <= -1) {
            trs[index].className += ' ' + 'box--grey';
          }
        }
      },
      _operateTrMouseout: function (index) {
        if (!this.expandable || this.fixedColumnCache.length > 0) {
          var trs = this.$el.querySelectorAll('[data-role="data-table-action-tr"]');
          if (this.fixedOperate && trs[index].className.indexOf('box--grey') > -1) {
            trs[index].className = trs[index].className.replace(new RegExp('(\\s|^)' + 'box--grey' + '(\\s|$)'), '');
          }
        }
      }
    }
  };

</script>
