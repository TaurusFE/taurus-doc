<template>
  <div class="form-item--toggle" :class="{'form-item--toggle--wide':wide}">
    <input class="toggle__radio" :id="'switcher-' + uuid + '-one'"
           data-toggle-value="on" type="radio"
           :value="true" :name="uuid"
           @click='onInput' :disabled='disabling'
           :checked='onCheck'>
    <label :for="'switcher-' + uuid + '-one'" v-html='onText'></label>
    <input class="toggle__radio" :id="'switcher-' + uuid + '-two'"
           data-toggle-value="off" type="radio" :value="false" :name="uuid"
           @click='onInput' :disabled='disabling'
           :checked='!onCheck'>
    <label :for="'switcher-' + uuid + '-two'" v-html='offText'></label>
    <div class="form-item--toggle__switch">
      <span class="icon icon-hamburger-menu"></span>
    </div>
    <div class="form-item--toggle__track"></div>
  </div>
</template>
<script>
  export default {
    props: {
      onText: {
        type: String,
        required: true,
        default: 'ON'
      },
      offText: {
        type: String,
        required: true,
        default: 'OFF'
      },
      value: {
        type: Boolean,
        default: true
      },
      disabled: {
        type: Boolean,
        default: false
      },
      wide: {   // 组件有两种宽度的表现形式，默认宽度和加宽模式（wide）
        type: Boolean,
        default: false
      },
      seq: {
        type: Number,
        default: 0
      }
    },
    computed: {
      seqInt () {
        var value = this.seq;
        if (isNaN(value) === false) {
          return parseInt(value);
        }
      }
    },
    data () {
      return {
        uuid: Math.random().toString(36).substring(3, 8), // 唯一标识
        onCheck: this.value,
        disabling: this.disabled
      };
    },
    watch: {
      value (newValue) {
        this.$emit('on-change', newValue, this.seqInt);
      }
    },
    methods: {
      onInput (event) {
        // event.target.value的值为字符串，这里需要转为bool值
        this.$emit('input', event.target.value === 'true');
      },
      toggle () {
        this.onCheck = !this.onCheck;
      },
      setValue (value) {
        if (this.onCheck !== value) {
          this.onCheck = value;
        }
      },
      getValue () {
        return this.onCheck;
      },
      enable () {
        this.disabling = false;
      },
      disable () {
        this.disabling = true;
      }
    }
  };
</script>
