<template>
  <div class="loader--centered" :class="{'fixed': value, 'loading-show': loadingState}" v-show="loadingState">
    <div :class="{'load-tester': isSpinner, 'load-large': isSetSize,'loader--light': islight }">
      <div :class="{ 'loader__spinner': isLoader, 'lightbox-spinner': isBox,'spinner': isSpinner }">
        <i></i>
      </div>
    </div>
  </div>
</template>
<style scoped>
  .loading-show{
    display: block;
  }
  .fixed {
    position: fixed
  }
</style>
<script>
  import Popup from '../popup/popup';
  export default {
    name: 't-loading',
    mixins: [Popup],
    data: function () {
      return {
        loadingState: true,
        isLoader: false,
        isBox: false,
        isSpinner: false,
        isSetSize: false,
        islight: false
      };
    },
    props: {
      enabled: {
        default: true,
        type: Boolean
      },
      loadType: {
        default: 'loader',
        type: String
      },
      size: {
        default: '',
        type: String
      },
      lightColor: {
        default: false,
        type: Boolean
      },
      fullScreen: {
        default: false,
        type: Boolean
      }
    },
    created: function () {
      if (!this.fullScreen) {
        this.loadingState = this.enabled;
      } else {
        this.loadingState = this.value;
      }
      let target = this.loadType;
      switch (target) {
        case 'loader':
          this.isLoader = true;
          if (this.lightColor) {
            this.islight = this.lightColor;
          } else if (this.size) {
            console.info('this.size设置不生效', this.size);
          }
          break;
        case 'circle':
          this.isBox = true;
          if (this.lightColor || this.size) {
            console.info('lightColor或size设置不生效');
          }
          break;
        case 'spinner':
          this.isSpinner = true;
          if (this.size === 'large') {
            this.isSetSize = true;
          } else if (this.lightColor) {
            console.info('lightColor设置不生效', this.lightColor);
          }
          break;
        default :
          console.warn('loadType参数错误加载默认loader');
          break;
      }
    },
    methods: {
      showLoading: function () {
        this.loadingState = true;
      },
      hideLoading: function () {
        this.loadingState = false;
      }
    },
    watch: {
      loadingState: function () {
        if (this.loadingState) {
          this.$emit('on-loading-visible');
        } else {
          this.$emit('on-loading-hidden');
        }
      },
      value: function () { // value 为mixins[popup]中的props。全屏状态下关闭模态层则关闭Loading，打开模态层则打开Loading
        if (this.value) {
          this.showLoading();
        } else {
          this.hideLoading();
        }
      }
    }
  };
</script>
