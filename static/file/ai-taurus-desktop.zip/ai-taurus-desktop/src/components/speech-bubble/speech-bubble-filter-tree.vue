<template>
  <component :is="compType" :size="size" :title="title" :target="target" show-close="false"
             v-on:speech-bubble-opend = "_openEvent" v-on:speech-bubble-closed = "_closeEvent">
    <div class="accordion-filter">
      <ul>
        <li v-for="(item, index) in itemArr" :class="item.className"
            @click.stop.prevent="_itemOnClick(item.id,$event)" :data-state="item.hcCheck" role="li">
          <!--没有子节点的li-->
          <input v-if="item.haveChild===false" :id="'tau-chk-nc-' + index" type="checkbox"
                 :name="itemName" :checked="item.checked" :disabled="item.disabled" :value="item.value"
                 :idx="item.id">
          <label v-if="item.haveChild===false" :for="'tau-chk-nc-' + index">{{item.label}}
            <span class="count" v-if="!!item.count&&item.count>0">({{item.count}})</span>
          </label>
          <!--有子节点的li-->
          <a v-if="item.haveChild===true" class="accordion-filter__parent-item-toggle" href="#"
             :idx="item.id" @click.stop.prevent="_itemOnClick(item.id,$event)" role="link-hc">
            <label>{{item.label}}
              <span class="count" v-if="!!item.count&&item.count>0">({{item.count}})</span>
            </label>
          </a>
          <a v-if="item.haveChild===true" href="#"
             class="accordion-filter__parent-item-expand icon icon-arrow-down"
             @click.stop.prevent="_itemOnClick(item.id,$event)" role="link-arrow"></a>
          <ul v-if="item.haveChild===true" class="accordion-filter__parent-item-list">
            <li v-for="(itemChild, indexChild) in item.item" class="accordion-filter__leaf-item form-checkbox" :idx="itemChild.id"
                @click.stop.prevent="_itemOnClick(itemChild.id,$event)" role="li-child">
              <input :id="'tau-chk-child-' + indexChild" type="checkbox"
                     :name="itemName" :checked="itemChild.checked" :disabled="itemChild.disabled"
                     :value="itemChild.value"
                     :idx="itemChild.id">
              <label :for="'tau-chk-child-' + indexChild" >{{itemChild.label}}
                <span class="count" v-if="!!itemChild.count&&itemChild.count>0">({{itemChild.count}})</span>
              </label>
            </li>
          </ul>
        </li>
      </ul>
    </div>
    <div class="box--greyed multi-filter__submit-panel">
      <button type="button" class="button button--action button--small" @click="_buttonClick">{{buttonName}}</button>
    </div>
  </component>
</template>
<script>
  import SpeechBubble from '../speech-bubble/speech-bubble.vue';

  const HAS_CHILD_ITEM_CLASS = 'accordion-filter__parent-item form-checkbox';
  const HAS_CHILD_ITEM_IS_EXPANDED_CLASS = 'accordion-filter__parent-item form-checkbox is-expanded';
  const NON_CHILD_ITEM_CLASS = 'accordion-filter__leaf-item accordion-filter__leaf-parent-item form-checkbox';
  const IS_EXPANDED_CLASS = 'is-expanded';
  const ALL_SELECTED = 'all-selected';
  const NON_SELECTED = 'non-selected';
  const SOME_SELECTED = 'some-selected';

  export default {
    name: 'taurus-speech-bubble-filter',
    components: {
      't-speech-bubble': SpeechBubble
    },
    data: function () {
      return {
        compType: 't-speech-bubble',
        isShow: false,
        itemArr: []
      };
    },
    props: {
      // 调用speech-bubble的组件id
      target: {
        type: String,
        required: true
      },
      // small或者large
      size: {
        default: 'large',
        type: String
      },
      // 标题名称
      title: {
        default: 'Speech Bubble',
        type: String
      },
      // 多选框的name属性
      itemName: {
        default: 'speech-bubble-filter-tree-check-name',
        type: String
      },
      // 按钮名称
      buttonName: {
        default: 'Update',
        type: String
      },
      modelValue: {
        default: '',
        type: [String, Array]
      },
//      /**
//       * [
//       * {
//       *   label: 'item4',  展示字段
//       *   checked: true,   是否选中
//       *   disabled: false, 是否可选
//       *   value: 'value4', 值
//       *   pid: '',         父节点ID
//       *   id: 4            节点ID
//        }
//       * ]
//       */
      items: {
        type: Array
      }
    },
    created: function () {
      this.items = this.itemsComputed;
    },
    computed: {
      itemsComputed: function () {
        this.itemArr = this.items;
        this._formatItems();
        return this.itemArr;
      }
    },
    methods: {
      /**
       * 打开方法
       */
      open: function () {
        this.$children[0].open();
      },
      /**
       * 关闭方法
       */
      close: function () {
        this.$children[0].close();
      },
      /**
       * 打开方法事件
       */
      _openEvent: function () {
        this.isShow = true;
        this.$emit('speech-bubble-opend');
      },
      /**
       * 关闭方法事件
       */
      _closeEvent: function () {
        this.isShow = false;
        // 调用关闭时的触发事件
        this.$emit('speech-bubble-closed');
      },
      getCheckItem: function () {
        var itemArrTemp = [];
        var valueArr = [];
        for (var o in this.itemArr) {
          if (this.itemArr[o].checked) {
            itemArrTemp.push(this.itemArr[o]);
            valueArr.push(this.itemArr[o].value);
          }
        }

        // 把选中的value值返回到前端
        this.$emit('input', valueArr.toString());
        return itemArrTemp;
      },
      _itemOnClick: function (id, event) {
        if (event) {
          var role = event.currentTarget.getAttribute('role');
          if (role === 'link-arrow') { // 箭头按钮
            var className = event.target.parentNode.getAttribute('class');
            if (className.indexOf(IS_EXPANDED_CLASS) <= -1) {
              event.target.parentNode.setAttribute('class', HAS_CHILD_ITEM_IS_EXPANDED_CLASS);
            } else {
              event.target.parentNode.setAttribute('class', HAS_CHILD_ITEM_CLASS);
            }
          } else {
            this._setItemCheckedById(id);
          }
        } else {
          this._setItemCheckedById(id);
        }
        this.getCheckItem();
      },
      _buttonClick: function (e) {
        this.$emit('speech-bubble-button-click');
      },
      _setItemCheckedById: function (id) {
        for (var o in this.itemArr) {
          if (this.itemArr[o].id && this.itemArr[o].id + '' === id + '') {
            Vue.set(this.itemArr[o], 'checked', !this.itemArr[o].checked);
            if (this.itemArr[o].haveChild) { // 如果是父节点 设置父节点下的子节点
              this._setParentItemChecked(id);
            } else if (this.itemArr[o].isChild) { // 如果是子节点 再去找父节点下的item数组设置值
              this._setChildItemChecked(id, this.itemArr[o].pid);
            }
          }
        }
      },
      // 设置父节点选中或取消选中
      _setParentItemChecked: function (pid) {
        for (var o in this.itemArr) {
          // 设置第一层数组中的子节点 父节点下第二层数组中的子节点会跟着更新
          if (!!this.itemArr[o].pid && this.itemArr[o].pid + '' === pid + '') {
            Vue.set(this.itemArr[o], 'checked', !this.itemArr[o].checked);
          } else if (!!this.itemArr[o].id && this.itemArr[o].id + '' === pid + '') { // 设置父节点选中 父节点选中方式不同 为更改class
            if (this.itemArr[o].checked) {
              Vue.set(this.itemArr[o], 'hcCheck', ALL_SELECTED);
            } else {
              Vue.set(this.itemArr[o], 'hcCheck', NON_SELECTED);
            }
          }
        }
      },
      // 设置子节点选中或取消选中
      _setChildItemChecked: function (id, pid) {
        var pidx, p, q;
        var count = 0;
        for (p in this.itemArr) {
          if (!!this.itemArr[p].id && this.itemArr[p].id + '' === pid + '') {
            pidx = p;
            for (q in this.itemArr[p].item) {
              if (this.itemArr[p].item[q].checked) {
                count++;
              }
            }
            break;
          }
        }
        if (this.itemArr[pidx].item.length === count && this.itemArr[pidx].item.length > 0) {
          Vue.set(this.itemArr[pidx], 'hcCheck', ALL_SELECTED);
        } else if (this.itemArr[pidx].item.length > count && this.itemArr[pidx].item.length > 0 && count > 0) {
          Vue.set(this.itemArr[pidx], 'hcCheck', SOME_SELECTED);
        } else {
          Vue.set(this.itemArr[pidx], 'hcCheck', NON_SELECTED);
        }
      },
      _formatItems: function () {
        // 循环出父节点 并给子元素标记isChild不对其进行使用 但是保留
        // 添加的状态 obj.haveChild=true 有子节点的父节点 obj.haveChild=false 没有子节点的父节点 obj.isChild = true;子节点 仅标记和取数据
        // obj.item 是存放子节点的数据
        for (var i = 0; i < this.itemArr.length; i++) {
          var obj = this.itemArr[i];
          var childCheckCount = 0;
          // 默认值 引入工具后可以用extend合并
          if (!obj.disabled) {
            obj.disabled = false;
          }
          if (!obj.checked) {
            obj.checked = false;
          }

          if (obj.id && obj.id !== '') {
            if (!obj.pid) { // 没有父节点
              obj.item = [];// 装子节点的数组
              // 把子节点放入父节点的object中
              for (var j = 0; j < this.itemArr.length; j++) {
                var obj1 = this.itemArr[j];
                if (obj1.pid && obj1.pid === obj.id) { // 有父节点
                  obj.item.push(obj1);
                  if (obj1.checked) {
                    childCheckCount++;
                  }
                }
              }
              // 根据子节点选中状态对父节点的选中状态赋值
              if (obj.item.length === childCheckCount && obj.item.length > 0) {
                obj.hcCheck = ALL_SELECTED;
              } else if (obj.item.length > childCheckCount && obj.item.length > 0 && childCheckCount > 0) {
                obj.hcCheck = SOME_SELECTED;
              } else {
                obj.hcCheck = NON_SELECTED;
              }

              // 分别定义有子节点的li的class和没有子节点的li的class复制
              if (obj.item.length === 0) {
                obj.className = NON_CHILD_ITEM_CLASS;
                obj.haveChild = false;
              } else {
                obj.className = HAS_CHILD_ITEM_CLASS;
                obj.haveChild = true;
              }
//              this.itemsFormat.push(obj);
            } else {
              obj.isChild = true;
            }
          } else {
            console.log('id is required:' + this.itemArr[i].label);
          }
        }
      }
    },
    watch: {
      modelValue: function (newValue, oldValue) {
        var checkValues = newValue;

        if (typeof newValue === 'string' && newValue !== '') {
          checkValues = newValue.split(',');
        } else {
          checkValues = newValue;
        }
        for (var i = 0; i < this.itemArr.length; i++) {
          Vue.set(this.itemArr[i], 'checked', false);
          for (var j = 0; j < checkValues.length; j++) {
            if (this.itemArr[i].value + '' === checkValues[j] + '') {
              Vue.set(this.itemArr[i], 'checked', true);
            }
          }
        }
        this._formatItems();
      }
    }
  };
</script>
