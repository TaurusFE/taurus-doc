<template>
  <transition name="expand">
    <div class="message trailer--small" :class="messageClass" v-if="visibledState" style="pointer-events:auto">
      <div class="message__inner">
        <span v-if="iconVisibled" class="message__icon icon" :class="iconClass"></span>
        <div class="text--small message__text">
          <p v-html="content" @click.stop.prevent="close($event)"></p>
        </div>
        <button v-if="closable" @click.stop.prevent="close($event)" data-role="closer" class="message__close">
          <span class="icon-remove" data-role="closer"></span>
        </button>
      </div>
    </div>
  </transition>
</template>
<script>
  const CSS_INFO = 'message--info';
  const CSS_SUCCESS = 'message--success';
  const CSS_ALERT = 'message--alert';
  const CSS_ERROR = 'message--error';
  const ICON_INFO = 'icon-notification';
  const ICON_SUCCESS = 'icon-check-grey';
  const ICON_ALERT = 'icon-error-no-bg';
  const ICON_ERROR = 'icon-reject';
  const TYPE_INFO = 'info';
  const TYPE_SUCCESS = 'success';
  const TYPE_ALERT = 'alert';
  const TYPE_ERROR = 'error';

  export default {
    name: 'taurus-status-message',
    created () {
      this._hdTimer = null;
      this.visibledState = this.visibled;
      if (this.delay > 0) {
        this.reDelay(this.delay);
      }
    },
    props: {
      type: {
        type: String,
        default: TYPE_INFO
      },
      delay: {
        type: Number,
        default: 0
      },
      visibled: {
        type: Boolean,
        default: true
      },
      iconVisibled: {
        type: Boolean,
        default: true
      },
      closable: {
        type: Boolean,
        default: true
      },
      content: {
        type: String,
        default: ''
      },
      oneOff: {
        type: Boolean,
        default: true
      }
    },
    data () {
      return {
        visibledState: false
      };
    },
    computed: {
      iconClass () {
        var typeToIcon = {};
        typeToIcon[TYPE_INFO] = ICON_INFO;
        typeToIcon[TYPE_SUCCESS] = ICON_SUCCESS;
        typeToIcon[TYPE_ALERT] = ICON_ALERT;
        typeToIcon[TYPE_ERROR] = ICON_ERROR;
        return typeToIcon[this.type];
      },
      messageClass () {
        var typeToCSS = {};
        typeToCSS[TYPE_INFO] = CSS_INFO;
        typeToCSS[TYPE_SUCCESS] = CSS_SUCCESS;
        typeToCSS[TYPE_ALERT] = CSS_ALERT;
        typeToCSS[TYPE_ERROR] = CSS_ERROR;
        return typeToCSS[this.type];
      }
    },
    methods: {
      show () {
        this.visibledState = true;
      },
      hide () {
        this.visibledState = false;
      },
      clearDelay () {
        if (this._hdTimer !== null) {
          this._hdTimer = null;
          window.clearTimeout(this._hdTimer);
        }
      },
      reDelay (delayTime) {
        var self = this;
        this.clearDelay();
        if (delayTime > 0) {
          this._hdTimer = window.setTimeout(() => {
            self.close();
          }, delayTime);
        }
      },
      _close (fireEvent) {
        var self = this;
        this.hide();
        if (fireEvent) {
          this.$emit('message-closed');
        }
        Vue.nextTick(() => {
          if (self.oneOff) {
            self.$destroy();
          }
        });
      },
      close (event) {
        var el;
        if (event) {
          el = event.target;
          if (el.getAttribute('data-role') === 'closer') {
            this._close(true);
          }
        } else {
          this._close();
        }
      }
    },
    beforeDestroy () {
      this.clearDelay();
    }
  };
</script>
<style scoped>
  .expand-enter-active{
    transition: opacity .5s
  }
  .expand-enter{
    opacity: 0;
  }
</style>
