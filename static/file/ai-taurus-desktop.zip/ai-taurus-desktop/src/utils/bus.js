import Vue from 'vue';
// 事件总线对象，用于简单的组件间通讯
export default new Vue();
