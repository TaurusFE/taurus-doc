let zIndex = 911107;
export const getZIndex = function () {
  return zIndex++;
};
