/**
 * Created by zengjie on 2016/11/3.
 * 用来配置业务上需要用到的配置项
 */
import constant from './constant';
var config = {
  common: {// 通用配置
    SERVICE_SWICTH: constant.SERVICE_INVOCATION_TYPE.RESTFUL, // 0:hub;1:restful 以hub还是restful方式调用服务
    DATE_FORMAT: 'yyyy-MM-dd hh:mm:ss', // 0:hub;1:restful 以hub还是restful方式调用服务
    MESSAGE_POSITION: 'top' // 消息提示插件展现的位置 'top' -- 顶端 ; 'bottom' -- 底端
  }
};

export default config;
